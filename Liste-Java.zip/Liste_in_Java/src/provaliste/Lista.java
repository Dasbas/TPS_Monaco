/**
 * 
 */
package provaliste;

/**
 * @author Daniele Lombardo
 *
 */
public class Lista {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i1 = 1;
		int i2 = 2;
		int i3 = 3;
		int i4 = 4;
		
		Nodo head = null;
		
		//System.out.println("Testa: " + head);
		Nodo n1 = new Nodo(i1, head);
		head = n1;
		
		//System.out.println("Testa: " + head);
		Nodo n2 = new Nodo(i2, head);
		head = n2;
		
		//System.out.println("Testa: " + head);
		Nodo n3 = new Nodo(i3, head);
		head = n3;
		
		//System.out.println("Testa: " + head);
		Nodo n4 = new Nodo(i4, head);
		head = n4;
		
		//System.out.println("Testa: " + head);
		
		while( head!=null ) {
			System.out.println( head.visualizza() );
			head = head.getLinkNodo();
		}

	}

}
